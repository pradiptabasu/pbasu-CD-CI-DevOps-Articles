node {
	def mvnHome
	stage('Preparation') {
		git url: 'GIT_REPO_URL', branch: 'BRANCH_NAME', credentialsId: 'CREDENTIALS_ID'
		mvnHome = tool 'Maven-3.3.9'
	}
	stage('Build') {
		// Run the maven build
      	if (isUnix()) {
         	sh "'${mvnHome}/bin/mvn' clean package -DskipTests docker:build"
      	} else {
         	bat(/"${mvnHome}\bin\mvn" clean package -DskipTests docker:build/)
      	}
    }
    stage('Publish') {
        // Push the image
		if (isUnix()) {
		    sh 'eval $(aws ecr get-login --region REGION_NAME)'
		    sh "'${mvnHome}/bin/mvn' docker:push"
		} else {
		    bat(/"${mvnHome}\bin\mvn" docker:push/)
        }
  	}
}
// we don't need this method now
def version() {
	def matcher = readFile('pom.xml') =~ '<version>(.+)</version>'
	matcher ? matcher[0][1] : null
}